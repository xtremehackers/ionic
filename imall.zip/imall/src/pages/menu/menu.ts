import { Component, ViewChild } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { HomePage } from '../home/home';
import { ProductsByCategoryPage } from '../products-by-category/products-by-category';
import { HttpClient } from '@angular/common/http';

/**
 * Generated class for the MenuPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-menu',
  templateUrl: 'menu.html',
})
export class MenuPage {

  homePage : any;
  apiData : any;
  wooCommerce : any;
  categories : any[];
  @ViewChild('content') childNavCtrl: NavController;

  constructor(public navCtrl: NavController, public navParams: NavParams, public httpClient: HttpClient) {
    this.httpClient.get('./assets/json/menu.json').subscribe(data => {

      let temp = data['product_categories'];
      
      for(let i = 0; i<temp.length; i++){
        if(temp[i].parent == 0){
          if(temp[i].slug == "clothing"){
            temp[i].icon = "shirt";
          }else if(temp[i].slug == "music"){
            temp[i].icon = "musical-notes";
          }else if(temp[i].slug == "posters"){
            temp[i].icon = "images";
          }
          this.categories.push(temp[i]);
        }
      }
    });
    this.homePage = HomePage;
    this.categories = [];

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad MenuPage');
  }

  openCategoryPage(category){
    this.navCtrl.push(ProductsByCategoryPage,{
      "category": category
    })


    // this.childNavCtrl.setRoot(ProductsByCategoryPage,{
    //   "category": category
    // })
  }
  
}
