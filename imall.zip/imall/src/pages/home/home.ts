import { Component , ViewChild} from '@angular/core';
import { NavController, Slides, ToastController } from 'ionic-angular';
import { ProductDetailsPage } from '../product-details/product-details';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  products : any[];
  moreProducts: any[] = [];
  page: number;

  @ViewChild('productSlides') productSlides: Slides;

  constructor(public navCtrl: NavController, public toastCtrl: ToastController, public httpClient: HttpClient) {
    
    this.page = 2;
        

    this.loadMoreProducts(null);

    this.httpClient.get('./assets/json/products.json').subscribe(data => {
      this.products = data['products'];
    });

  }

  ionViewDidLoad(){
    setInterval(()=>{
      if(this.productSlides.getActiveIndex() == this.productSlides.length() -1){
        this.productSlides.slideTo(0);
      }
      this.productSlides.slideNext();
    },3000);
  }

  loadMoreProducts(event){
    
    this.httpClient.get('./assets/json/products.json').subscribe(data => {
      //this.products = data.products;

      this.moreProducts = this.moreProducts.concat(data['products']);
      
      if(event != null){
          event.complete();
      

      
          if(data['products'].length < 15){
          event.enable(false);

          this.toastCtrl.create({
            message: "No more products!",
            duration: 5000
          }).present()
        }
      }
      


    });

  }

  openProductPage(product){
    this.navCtrl.push(ProductDetailsPage,{
      "product": product
    } )
  }

}
