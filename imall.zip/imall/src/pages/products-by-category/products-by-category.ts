import { Component } from '@angular/core';
import { NavController, NavParams, ToastController } from 'ionic-angular';
import { ProductDetailsPage } from '../product-details/product-details';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'page-products-by-category',
  templateUrl: 'products-by-category.html',
})
export class ProductsByCategoryPage {

  products: any[] = [];
  page: number;
  category: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public toastCtrl: ToastController, public httpClient: HttpClient) {

    this.page = 1;
    this.category = this.navParams.get("category");
    

    this.httpClient.get('./assets/json/products.json').subscribe(data => {
      this.products = data['products'];
    });

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ProductsByCategoryPage');
  }

  loadMoreProducts(event){

    this.httpClient.get('./assets/json/products.json').subscribe(data => {
      //this.products = data.products;

      this.products = this.products.concat(data['products']);
      
      if(event != null){
          event.complete();
      

      
          if(data['products'].length < 15){
          event.enable(false);

          this.toastCtrl.create({
            message: "No more products!",
            duration: 5000
          }).present()
        }
      }
      


    });

  }

  openProductPage(product){
    this.navCtrl.push(ProductDetailsPage,{
      "product": product
    } )
  }

}
